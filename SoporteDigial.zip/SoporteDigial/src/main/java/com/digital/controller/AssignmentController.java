package com.digital.controller;

import com.digital.dto.AssignmentSummaryDTO;
import com.digital.entities.Assignment;
import com.digital.entities.User;
import com.digital.exception.ResourceNotFoundException;
import com.digital.service.AssignmentServiceImpl;
import com.digital.service.UserServiceImpl;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class AssignmentController {


    @Autowired
    private AssignmentServiceImpl assignmentService;


    @Autowired
    private UserServiceImpl userService;


    private boolean isAdmin(Authentication authentication) {
        User user = userService.findByEmail(authentication.getName());
        return user.getRole() == User.Role.ADMIN;
    }

    private boolean isAgent(Authentication authentication) {
        User user = userService.findByEmail(authentication.getName());
        return user.getRole() == User.Role.AGENT;
    }


    @GetMapping("/assignments")
    public ResponseEntity<List<Assignment>> getAllAssignments(Authentication authentication) {

        if(isAdmin(authentication)) {
            return ResponseEntity.ok(assignmentService.findAllAssignments());
        } else if (isAgent(authentication)) {
            User user = userService.findByEmail(authentication.getName());
            List<Assignment> assignments = assignmentService.findByAgentId(user.getId());
            return ResponseEntity.ok(assignments);
        }

        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    @PostMapping("/assignments")
    public ResponseEntity<AssignmentSummaryDTO> addAssignment(@RequestBody Assignment assignment, Authentication authentication) {

        User user = userService.findByEmail(authentication.getName());

        if (!user.getRole().equals(User.Role.ADMIN) && !user.getRole().equals(User.Role.AGENT)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        }

        assignment.setAssignedAt(new Date());
        assignment.setUpdatedAt(new Date());
        assignment.setUpdatedByUser(user);
        assignment.setAssignmentStatus(Assignment.AssignmentStatus.PENDING);

        Assignment savedAssignment = assignmentService.saveAssignment(assignment);

        AssignmentSummaryDTO dto = new AssignmentSummaryDTO(
                savedAssignment.getIsCoordinator(),
                savedAssignment.getAssignedAt(),
                savedAssignment.getUpdatedAt(),
                savedAssignment.getUpdatedByUser(),
                savedAssignment.getAssignmentStatus()
        );

        return ResponseEntity.status(HttpStatus.CREATED).body(dto);

    }

    @GetMapping("/assignments/{id}")
    public ResponseEntity<Assignment> getAssignmentById(@PathVariable Long id, Authentication authentication) {

        Assignment assignment = assignmentService.findAssignmentById(id);
        User user = userService.findByEmail(authentication.getName());

        if (isAdmin(authentication)) {
            return ResponseEntity.ok(assignment);

        }

        if(isAgent(authentication) && assignment.getAgent().getId().equals(user.getId())) {
            return ResponseEntity.ok(assignment);
        }

        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

    }


    @PutMapping("/assignments/{id}")
    public ResponseEntity<Assignment> updateAssignment(@PathVariable Long id, @RequestBody Assignment assignment, Authentication authentication) {

        Assignment existingAssignment = assignmentService.findAssignmentById(id);
        User user = userService.findByEmail(authentication.getName());

        if(isAdmin(authentication) || (isAgent(authentication) && existingAssignment.getAgent().getId().equals(user.getId()))) {
            existingAssignment.setAssignmentStatus(assignment.getAssignmentStatus());
            existingAssignment.setIsCoordinator(assignment.getIsCoordinator());
            existingAssignment.setUpdatedAt(new Date());
            existingAssignment.setUpdatedByUser(assignment.getUpdatedByUser());

            this.assignmentService.saveAssignment(existingAssignment);
            return ResponseEntity.ok(existingAssignment);

        }

        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    @DeleteMapping("/assignments/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteAssignment(@PathVariable Long id, Authentication authentication) {

        if(!isAdmin(authentication)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Assignment assignment = assignmentService.findAssignmentById(id);

        if(assignment == null) {
            throw new ResourceNotFoundException("Assignment not found id: " + id);
        }

        assignmentService.deleteAssignment(assignment.getId());

        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);

    }


    @GetMapping("/assignments/agent/{agentId}")
    public ResponseEntity<List<Assignment>> getAssignmentsByAgent(@PathVariable Long agentId, Authentication authentication) {

        if(isAdmin(authentication)) {
            List<Assignment> assignments = assignmentService.findByAgentId(agentId);
            if(assignments.isEmpty()) {
                return ResponseEntity.ok(Collections.emptyList());
            }
            return ResponseEntity.ok(assignments);
        }

        User user = userService.findByEmail(authentication.getName());
        if(isAgent(authentication) && user.getId().equals(agentId)) {
            List<Assignment> assignments = assignmentService.findByAgentId(user.getId());
            if(assignments.isEmpty()) {
                return ResponseEntity.ok(Collections.emptyList());

            }
            return ResponseEntity.ok(assignments);
        }
        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

    }


    @GetMapping("/assignments/status/{assignmentStatus}")
    public ResponseEntity<List<Assignment>> getAssignmentsByStatus(@PathVariable Assignment.AssignmentStatus assignmentStatus,Authentication authentication) {

        if(!isAdmin(authentication)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        }
        List<Assignment> assignments = assignmentService.findByAssignmentStatus(assignmentStatus);

        if (assignments.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }

        return ResponseEntity.ok(assignments);
    }


    @GetMapping("/assignments/support-request/{supportRequestId}")
    public ResponseEntity<List<Assignment>> getAssignmentsBySupportRequest(@PathVariable Long supportRequestId, Authentication authentication) {

        if(!isAdmin(authentication)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        List<Assignment> assignments = assignmentService.findBySupportRequestId(supportRequestId);

        if (assignments.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }

        return ResponseEntity.ok(assignments);
    }

    @GetMapping("/assignments/agent/{agentId}/status/{assignmentStatus}")
    public ResponseEntity<List<Assignment>> getAssignmentsByAgentAndStatus(@PathVariable Long agentId, @PathVariable Assignment.AssignmentStatus assignmentStatus, Authentication authentication) {
        if(!isAdmin(authentication)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        List<Assignment> assignments = assignmentService.findByAgentIdAndAssignmentStatus(agentId, assignmentStatus);

        if (assignments.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList());
        }
        return ResponseEntity.ok(assignments);
    }

}




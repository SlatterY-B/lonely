package com.digital.entities.repository;

import com.digital.entities.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, Long> {


    List<Assignment> findByAgentId(Long agentId);

    List<Assignment> findByAssignmentStatus(Assignment.AssignmentStatus assignmentStatus);

    List<Assignment> findBySupportRequestId(Long supportRequestId);

    List<Assignment> findByAgentIdAndAssignmentStatus(Long agentId, Assignment.AssignmentStatus assignmentStatus);


}

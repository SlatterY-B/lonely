package com.digital.entities.repository;

import com.digital.entities.SupportRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface SupportRequestRepository extends JpaRepository<SupportRequest, Long> {

    List<SupportRequest> findAllByCustomerId(Long customerId);


    List<SupportRequest> findByRequestStatus(SupportRequest.RequestStatus requestStatus);

    List<SupportRequest> findByCreatedAtBetween(Date startDate, Date endDate);

    List<SupportRequest>  findByRequestType(SupportRequest.RequestType requestType);

    List<SupportRequest> findByCustomerIdAndRequestStatus(Long customerId, SupportRequest.RequestStatus requestStatus);

    List<SupportRequest> findByRequestTypeAndRequestStatus(SupportRequest.RequestType requestType, SupportRequest.RequestStatus requestStatus);
}

package com.digital.service;

import com.digital.entities.SupportRequest;
import com.digital.entities.repository.SupportRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class SupportRequestServiceImpl implements SupportRequestService {

    @Autowired
    private SupportRequestRepository supportRequestRepository;

    @Override
    public List<SupportRequest> findAllSupportRequests() {
        return supportRequestRepository.findAll();
    }

    @Override
    public SupportRequest findSupportRequestById(Long id) {
        return supportRequestRepository.findById(id).orElseThrow(() -> new RuntimeException("Support request not found"));
    }

    @Override
    public SupportRequest saveSupportRequest(SupportRequest supportRequest) {
        return supportRequestRepository.save(supportRequest);
    }

    @Override
    public void deleteSupportRequest(Long id) {

        SupportRequest supportRequest = findSupportRequestById(id);
        supportRequestRepository.delete(supportRequest);

    }

    @Override
    public List<SupportRequest> findByCustomerId(Long customerId) {
        return supportRequestRepository.findAllByCustomerId(customerId);
    }

    @Override
    public List<SupportRequest> findByRequestStatus(SupportRequest.RequestStatus requestStatus) {
        return supportRequestRepository.findByRequestStatus(requestStatus);
    }

    @Override
    public List<SupportRequest> findByCreatedAtBetween(Date startDate, Date endDate) {
        return supportRequestRepository.findByCreatedAtBetween(startDate, endDate);
    }

    @Override
    public List<SupportRequest> findByRequestType(SupportRequest.RequestType requestType) {
        return supportRequestRepository.findByRequestType(requestType);
    }

    @Override
    public List<SupportRequest> findByCustomerIdAndRequestStatus(Long customerId, SupportRequest.RequestStatus requestStatus) {
        return supportRequestRepository.findByCustomerIdAndRequestStatus(customerId, requestStatus);
    }

    @Override
    public List<SupportRequest> findByRequestTypeAndRequestStatus(SupportRequest.RequestType requestType, SupportRequest.RequestStatus requestStatus) {
        return supportRequestRepository.findByRequestTypeAndRequestStatus(requestType, requestStatus);
    }
}

package com.digital.service;

import com.digital.entities.User;

import java.util.List;

public interface UserService {


    List<User> findAll();

    User findById(Long id);

    User save(User user);

    void delete(Long id);

    User findByEmail(String email);

}

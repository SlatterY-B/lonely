package com.digital.service;

import com.digital.entities.Assignment;
import com.digital.entities.repository.AssignmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AssignmentServiceImpl implements AssignmentService {


    @Autowired
    private AssignmentRepository assignmentRepository;


    @Override
    public List<Assignment> findAllAssignments() {
        return assignmentRepository.findAll();
    }

    @Override
    public Assignment findAssignmentById(Long id) {
        return assignmentRepository.findById(id).orElseThrow(() -> new RuntimeException("Assignment not found"));
    }

    @Override
    public Assignment saveAssignment(Assignment assignment) {
        return assignmentRepository.save(assignment);
    }

    @Override
    public void deleteAssignment(Long id) {

        Assignment assignment = findAssignmentById(id);
        assignmentRepository.delete(assignment);

    }

    @Override
    public List<Assignment> findByAgentId(Long agentId) {
        return assignmentRepository.findByAgentId(agentId);
    }

    @Override
    public List<Assignment> findByAssignmentStatus(Assignment.AssignmentStatus assignmentStatus) {
        return assignmentRepository.findByAssignmentStatus(assignmentStatus);
    }

    @Override
    public List<Assignment> findBySupportRequestId(Long supportRequestId) {
        return assignmentRepository.findBySupportRequestId(supportRequestId);
    }

    @Override
    public List<Assignment> findByAgentIdAndAssignmentStatus(Long agentId, Assignment.AssignmentStatus assignmentStatus) {
        return assignmentRepository.findByAgentIdAndAssignmentStatus(agentId, assignmentStatus);
    }
}

package com.digital.dto;

import com.digital.entities.Assignment;
import com.digital.entities.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.annotations.SecondaryRow;

import java.util.Date;

@Data
@AllArgsConstructor
public class AssignmentSummaryDTO {

    private Boolean isCordinator;
    private Date assignedAt;
    private Date updatedAt;
    private User updatedByUser;
    private Assignment.AssignmentStatus assignmentStatus;

}
